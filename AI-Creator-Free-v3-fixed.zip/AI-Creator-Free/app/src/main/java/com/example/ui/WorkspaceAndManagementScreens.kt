package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.i18n.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioDestination
import com.example.viewmodel.StudioViewModel

/**
 * Section 25: PROJECTS WORKSPACE SCREEN (Folders, Style Lock, Duplicate, Trash & Restore, Cloud Firestore Sync)
 */
@Composable
fun ProjectsWorkspaceScreen(
    viewModel: StudioViewModel,
    activeProjects: List<ProjectEntity>,
    trashedProjects: List<ProjectEntity>
) {
    var showTrash by remember { mutableStateOf(false) }
    val cloudStatus by viewModel.firestoreSyncStatus.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Projects & Cloud Workspace", style = MaterialTheme.typography.headlineMedium, color = StudioTextPrimary)
                    Text(cloudStatus, style = MaterialTheme.typography.bodySmall, color = StudioCyanAccent)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.syncWorkspaceToFirestoreNow() }) {
                        Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sync Firestore")
                    }
                    FilterChip(
                        selected = !showTrash,
                        onClick = { showTrash = false },
                        label = { Text("Active (${activeProjects.size})") }
                    )
                    FilterChip(
                        selected = showTrash,
                        onClick = { showTrash = true },
                        label = { Text("Trash (${trashedProjects.size})") }
                    )
                }
            }
        }

        val listToDisplay = if (showTrash) trashedProjects else activeProjects
        items(listToDisplay, key = { it.id }) { project ->
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(project.title, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                            Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = "${project.aspectRatio} • ${project.resolution} • v${project.currentVersion}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioCyanAccent,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(project.description, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        Text(
                            "Concept: ${project.concept.ifBlank { project.styleReferenceName }} • Status: ${project.autosaveStatus}",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (!showTrash) {
                            OutlinedButton(onClick = { viewModel.toggleProjectStyleLock(project) }) {
                                Text(if (project.styleLockEnabled) "Style Locked" else "Lock Style")
                            }
                            OutlinedButton(onClick = {
                                viewModel.selectActiveProject(project.id)
                            }) {
                                Text("Open")
                            }
                            OutlinedButton(onClick = { viewModel.duplicateProject(project) }) {
                                Text("Duplicate")
                            }
                            IconButton(onClick = { viewModel.moveProjectToTrash(project) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Trash", tint = StudioRoseDanger)
                            }
                        } else {
                            Button(onClick = { viewModel.restoreProjectFromTrash(project) }) {
                                Text("Restore")
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Section 27: ASSET LIBRARY SCREEN
 */
@Composable
fun AssetLibraryScreen(
    viewModel: StudioViewModel,
    assets: List<AssetEntity>
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    val filteredAssets = remember(assets, selectedFilter) {
        if (selectedFilter == "ALL") assets else assets.filter { it.type == selectedFilter }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Global Asset Vault & Generated Media", style = MaterialTheme.typography.headlineMedium, color = StudioTextPrimary)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "VIDEO", "IMAGE", "VOICE", "MUSIC", "SFX", "SUBTITLE").forEach { type ->
                    FilterChip(
                        selected = selectedFilter == type,
                        onClick = { selectedFilter = type },
                        label = { Text(type) }
                    )
                }
            }
        }

        items(filteredAssets, key = { it.id }) { asset ->
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = asset.type,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioCyanAccent,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Text(asset.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                        }
                        if (asset.promptUsed.isNotBlank()) {
                            Text(
                                "Prompt: ${asset.promptUsed}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            "${asset.formatInfo} • ${asset.durationSec}s • Folder: ${asset.folder}",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextMuted
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (asset.type in listOf("VOICE", "MUSIC", "SFX", "AUDIO")) {
                            FilledTonalButton(onClick = {
                                viewModel.previewSynthesizedAudio(mode = asset.type, freq = asset.audioFreqHz.toDouble())
                            }) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Audition")
                            }
                        }
                        IconButton(onClick = { viewModel.toggleAssetFavorite(asset) }) {
                            Icon(
                                imageVector = if (asset.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (asset.isFavorite) StudioRoseDanger else StudioTextSecondary
                            )
                        }
                        IconButton(onClick = { viewModel.deleteAsset(asset.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = StudioTextMuted)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Sections 22 & 23: TEMPLATES & PROMPT MARKETPLACE SCREEN
 */
@Composable
fun TemplatesAndPromptsScreen(
    viewModel: StudioViewModel,
    templates: List<PromptTemplateEntity>
) {
    var customTitle by remember { mutableStateOf("") }
    var customCategory by remember { mutableStateOf("Ads") }
    var customPrompt by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Global Templates & Prompt Library", style = MaterialTheme.typography.headlineMedium, color = StudioTextPrimary)
            Text("One-click commercial presets for YouTube, TikTok, Luxury Ads, Podcasts & SaaS.", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
        }

        items(templates, key = { it.id }) { tpl ->
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = tpl.category,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioPrimaryBright,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Text(tpl.title, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        }
                        Text("${tpl.aspectRatio} • ${tpl.durationSec}s", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                    }
                    Text(tpl.promptText, style = MaterialTheme.typography.bodyMedium, color = StudioTextSecondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Style: ${tpl.previewStyle} • Vars: ${tpl.variablesCsv}", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { viewModel.toggleTemplateFavorite(tpl) }) {
                                Icon(
                                    imageVector = if (tpl.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (tpl.isFavorite) StudioAmberWarning else StudioTextSecondary
                                )
                            }
                            Button(onClick = { viewModel.useTemplateInDirector(tpl) }) {
                                Text("Load in AI Director")
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("SAVE CUSTOM REUSABLE PROMPT TEMPLATE", style = MaterialTheme.typography.titleSmall, color = StudioCyanAccent)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = customTitle, onValueChange = { customTitle = it }, label = { Text("Template Title") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = customCategory, onValueChange = { customCategory = it }, label = { Text("Category") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(
                        value = customPrompt,
                        onValueChange = { customPrompt = it },
                        label = { Text("Prompt Template with {product}, {location}, {mood}") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (customTitle.isNotBlank() && customPrompt.isNotBlank()) {
                                viewModel.saveCustomPromptTemplate(customTitle, customCategory, customPrompt, "{product},{location},{mood}")
                                customTitle = ""
                                customPrompt = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Prompt to Library")
                    }
                }
            }
        }
    }
}

/**
 * Section 24: BRAND KIT SCREEN
 */
@Composable
fun BrandKitScreen(
    viewModel: StudioViewModel,
    brandKits: List<BrandKitEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Enterprise Brand Kits", style = MaterialTheme.typography.headlineMedium, color = StudioTextPrimary)
            Text("Enforce brand colors, typography, watermark, sonic intro, and CTA outro across every AI generation.", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
        }

        items(brandKits, key = { it.id }) { kit ->
            var name by remember(kit.id) { mutableStateOf(kit.name) }
            var primaryHex by remember(kit.id) { mutableStateOf(kit.primaryColorHex) }
            var secondaryHex by remember(kit.id) { mutableStateOf(kit.secondaryColorHex) }
            var fontName by remember(kit.id) { mutableStateOf(kit.fontFamilyName) }
            var introStyle by remember(kit.id) { mutableStateOf(kit.introStyle) }
            var outroStyle by remember(kit.id) { mutableStateOf(kit.outroStyle) }

            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(kit.name, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        Text("${kit.primaryColorHex} • ${kit.secondaryColorHex}", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                    }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Brand Name") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = primaryHex, onValueChange = { primaryHex = it }, label = { Text("Primary Hex") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = secondaryHex, onValueChange = { secondaryHex = it }, label = { Text("Secondary Hex") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = fontName, onValueChange = { fontName = it }, label = { Text("Typography Font Family") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = introStyle, onValueChange = { introStyle = it }, label = { Text("Intro Style") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = outroStyle, onValueChange = { outroStyle = it }, label = { Text("Outro CTA Style") }, modifier = Modifier.weight(1f))
                    }
                    Button(
                        onClick = {
                            viewModel.updateBrandKit(
                                kit.copy(
                                    name = name,
                                    primaryColorHex = primaryHex,
                                    secondaryColorHex = secondaryHex,
                                    fontFamilyName = fontName,
                                    introStyle = introStyle,
                                    outroStyle = outroStyle
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save & Enforce Brand Kit")
                    }
                }
            }
        }
    }
}

/**
 * Section 28: CONTEXT-AWARE AI CREATIVE ASSISTANT SCREEN
 */
@Composable
fun AiAssistantChatScreen(
    viewModel: StudioViewModel
) {
    val chatTurns by viewModel.assistantChat.collectAsStateWithLifecycle()
    var inputMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(20.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Context-Aware AI Creative Co-Director", style = MaterialTheme.typography.headlineMedium, color = StudioTextPrimary)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "Brighten Scene 2 lighting (+1.5 EV)",
                    "Make narrator voice more serious & authoritative",
                    "Make music score more energetic (126 BPM)",
                    "Trim timeline to 15s for Instagram Reels 9:16",
                    "Add heavy rain & thunder foley SFX"
                ).forEach { quickAsk ->
                    AssistChip(
                        onClick = { viewModel.sendAssistantCommand(quickAsk) },
                        label = { Text(quickAsk) }
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatTurns, key = { it.id }) { turn ->
                val isUser = turn.sender == "USER"
                Surface(
                    color = if (isUser) StudioPrimaryContainer else StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (isUser) StudioPrimaryIndigo else StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (isUser) "YOU" else "AI CO-DIRECTOR (GEMINI 3.1 PRO)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isUser) StudioCyanAccent else StudioEmeraldSuccess
                        )
                        Text(turn.message, style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                        turn.actionProposal?.let { proposal ->
                            Surface(
                                color = StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Action Proposal: ${proposal.suggestedActionType}", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                                        Text(proposal.previewSummary, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                                    }
                                    Button(
                                        onClick = { viewModel.applyAssistantProposal(turn.id) },
                                        enabled = !turn.isApplied
                                    ) {
                                        Text(if (turn.isApplied) "Applied" else "Apply to Timeline")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputMessage,
                onValueChange = { inputMessage = it },
                placeholder = { Text("Ask AI Assistant to rewrite scenes, hooks, camera shots, or pacing...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("assistant_input_field")
            )
            Button(
                onClick = {
                    viewModel.sendAssistantCommand(inputMessage)
                    inputMessage = ""
                },
                enabled = inputMessage.isNotBlank(),
                modifier = Modifier.testTag("assistant_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

/**
 * Sections 26 & 29: GENERATION QUEUE, HISTORY & MULTI-FORMAT EXPORT CENTER
 */
@Composable
fun GenerationHistoryAndExportScreen(
    viewModel: StudioViewModel,
    jobs: List<GenerationJobEntity>,
    initialIsExport: Boolean
) {
    var isExportTab by remember(initialIsExport) { mutableStateOf(initialIsExport) }
    var exportFormat by remember { mutableStateOf("MP4 Video (H.264 / 4K)") }
    var exportResolution by remember { mutableStateOf("4K UHD (3840x2160)") }
    var exportFps by remember { mutableIntStateOf(60) }
    var burnInSubtitles by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isExportTab) "Multi-Format Render & Export Center" else "Async AI Generation Queue & History",
                    style = MaterialTheme.typography.headlineMedium,
                    color = StudioTextPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isExportTab,
                        onClick = { isExportTab = false },
                        label = { Text("Jobs Queue (${jobs.size})") }
                    )
                    FilterChip(
                        selected = isExportTab,
                        onClick = { isExportTab = true },
                        label = { Text("Render & Export") }
                    )
                }
            }
        }

        if (isExportTab) {
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("MASTER RENDER CONFIGURATION", style = MaterialTheme.typography.titleMedium, color = StudioCyanAccent)
                        Text("Select container format:", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "MP4 Video (H.264 / 4K)",
                                "MOV ProRes 422",
                                "WAV Lossless Audio Stems",
                                "MP3 Podcast Master",
                                "SRT + VTT Multilingual Subtitles",
                                "Full Project Archive (.ZIP)"
                            ).forEach { fmt ->
                                FilterChip(
                                    selected = exportFormat == fmt,
                                    onClick = { exportFormat = fmt },
                                    label = { Text(fmt) }
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("720p HD", "1080p Full HD", "4K UHD (3840x2160)").forEach { res ->
                                FilterChip(
                                    selected = exportResolution == res,
                                    onClick = { exportResolution = res },
                                    label = { Text(res) }
                                )
                            }
                            listOf(24, 30, 60).forEach { fps ->
                                FilterChip(
                                    selected = exportFps == fps,
                                    onClick = { exportFps = fps },
                                    label = { Text("$fps FPS") }
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Checkbox(checked = burnInSubtitles, onCheckedChange = { burnInSubtitles = it })
                            Text("Include Multilingual Subtitle Track + Burn-In Styling", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                        }

                        Button(
                            onClick = {
                                viewModel.launchModalityGeneration(
                                    jobType = "EXPORT",
                                    title = "Master Render ($exportFormat)",
                                    prompt = "Master Export: $exportFormat, $exportResolution, ${exportFps}fps, Subtitles=$burnInSubtitles",
                                    resolutionOrFormat = "$exportResolution @ ${exportFps}fps",
                                    durationSec = 30,
                                    creditCost = 20
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_master_export_button")
                        ) {
                            Icon(Icons.Default.MovieCreation, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Queue Cloud Master Render (20 Credits)")
                        }
                    }
                }
            }
        }

        items(jobs, key = { it.id }) { job ->
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = job.jobType,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioPrimaryBright,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Text(job.modelName, style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                        }
                        Text(
                            text = "${job.status} (${job.progressPercent}%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = when (job.status) {
                                "COMPLETED" -> StudioEmeraldSuccess
                                "FAILED" -> StudioRoseDanger
                                else -> StudioAmberWarning
                            }
                        )
                    }
                    Text(job.prompt, style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                    if (job.outputSummary.isNotBlank()) {
                        Text(job.outputSummary, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                    }
                    if (job.status !in listOf("COMPLETED", "FAILED")) {
                        LinearProgressIndicator(
                            progress = { job.progressPercent / 100f },
                            modifier = Modifier.fillMaxWidth(),
                            color = StudioCyanAccent
                        )
                    }
                }
            }
        }
    }
}

/**
 * Sections 30, 31, 37, 56–58, 72:
 * BILLING, CREDITS, GLOBAL MULTILINGUAL / RTL SETTINGS, FIREBASE AUTH & FIRESTORE SYNC, THEME SWITCHER
 */
@Composable
fun BillingAndAdminScreen(
    viewModel: StudioViewModel,
    credits: Int,
    planName: String,
    transactions: List<CreditTransactionEntity>,
    jobs: List<GenerationJobEntity>,
    initialIsSettingsAdmin: Boolean
) {
    val context = LocalContext.current
    val i18n = LocalStudioLocalizer.current
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val currentCurrency by viewModel.selectedCurrency.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val experienceMode by viewModel.experienceMode.collectAsStateWithLifecycle()
    val cloudSession by viewModel.cloudSession.collectAsStateWithLifecycle()
    val firestoreSyncStatus by viewModel.firestoreSyncStatus.collectAsStateWithLifecycle()

    var isSettingsTab by remember(initialIsSettingsAdmin) { mutableStateOf(initialIsSettingsAdmin) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isSettingsTab) "${i18n.t("nav.settings")} & Global Cloud" else i18n.t("nav.billing"),
                    style = MaterialTheme.typography.headlineMedium,
                    color = StudioTextPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isSettingsTab,
                        onClick = { isSettingsTab = false },
                        label = { Text(i18n.t("nav.billing")) }
                    )
                    FilterChip(
                        selected = isSettingsTab,
                        onClick = { isSettingsTab = true },
                        label = { Text(i18n.t("nav.settings")) }
                    )
                }
            }
        }

        if (!isSettingsTab) {
            // Regional Currency Switcher + Subscription Tiers
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("CURRENT PLAN: ${planName.uppercase()}", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                                Text(
                                    "$credits ${i18n.t("billing.credits")}",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = StudioEmeraldSuccess
                                )
                            }
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                StudioCurrency.entries.forEach { curr ->
                                    FilterChip(
                                        selected = currentCurrency == curr,
                                        onClick = { viewModel.setStudioCurrency(curr) },
                                        label = { Text("${curr.code} (${curr.symbol})") }
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            listOf(
                                Triple("Free", 150 to 0.0, "720p + Watermark"),
                                Triple("Creator", 600 to 19.0, "1080p + No Watermark"),
                                Triple("Pro Studio", 1500 to 49.0, "4K + Lyria 3 Pro Stems"),
                                Triple("Enterprise Studio", 5000 to 149.0, "4K + Cloud Team Sync + Priority Queue")
                            ).forEach { (tier, bonusAndPrice, perks) ->
                                val (bonus, usdPrice) = bonusAndPrice
                                Surface(
                                    color = if (planName == tier) StudioPrimaryContainer else StudioSurfaceElevated,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .width(220.dp)
                                        .border(1.dp, if (planName == tier) StudioPrimaryIndigo else StudioBorderSubtle, RoundedCornerShape(12.dp))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(tier, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                        Text(
                                            "${i18n.formatCurrency(usdPrice, currentCurrency)} / mo",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = StudioCyanAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text("+$bonus Credits", style = MaterialTheme.typography.labelMedium, color = StudioEmeraldSuccess)
                                        Text(perks, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                                        Button(
                                            onClick = { viewModel.switchSubscriptionPlan(tier, bonus) },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(if (planName == tier) "Top Up +$bonus" else "Select $tier")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text("TRANSACTION-SAFE CREDIT LEDGER (IDEMPOTENT)", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
            }

            items(transactions, key = { it.id }) { tx ->
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(tx.description, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                            Text(
                                "${i18n.formatDateTime(tx.createdAt)} • Key: ${tx.idempotencyKey}",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (tx.deltaCredits >= 0) "+${tx.deltaCredits} CR" else "${tx.deltaCredits} CR",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (tx.deltaCredits >= 0) StudioEmeraldSuccess else StudioAmberWarning
                            )
                            Text("Bal: ${tx.balanceAfter}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                        }
                    }
                }
            }
        } else {
            // GLOBAL LANGUAGE & RTL ENGINE (19 Languages)
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("GLOBAL 19-LANGUAGE LOCALIZATION & RTL ENGINE", style = MaterialTheme.typography.titleMedium, color = StudioCyanAccent)
                        Text(
                            "Active Language: ${currentLanguage.nativeName} (${currentLanguage.englishName}) • Layout Direction: ${if (currentLanguage.isRtl) "RTL (Right-to-Left)" else "LTR (Left-to-Right)"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioEmeraldSuccess
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(StudioLanguage.entries) { lang ->
                                FilterChip(
                                    selected = currentLanguage == lang,
                                    onClick = { viewModel.setStudioLanguage(lang) },
                                    label = { Text("${lang.nativeName} (${lang.code.uppercase()})") }
                                )
                            }
                        }
                    }
                }
            }

            // APPEARANCE (DARK / LIGHT STUDIO MODE) & COMPLEXITY (SIMPLE / CREATOR / PRO)
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("APPEARANCE & WORKSPACE EXPERIENCE", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FilterChip(
                                selected = isDarkMode,
                                onClick = { if (!isDarkMode) viewModel.toggleDarkMode() },
                                label = { Text("Cinematic Dark Studio (Default)") }
                            )
                            FilterChip(
                                selected = !isDarkMode,
                                onClick = { if (isDarkMode) viewModel.toggleDarkMode() },
                                label = { Text("High-Contrast Daylight Studio") }
                            )
                        }
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StudioExperienceMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = experienceMode == mode,
                                    onClick = { viewModel.setExperienceMode(mode) },
                                    label = { Text(mode.label) }
                                )
                            }
                        }
                    }
                }
            }

            // FIREBASE AUTHENTICATION & CLOUD FIRESTORE WORKSPACE SYNC
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("FIREBASE AUTHENTICATION & FIRESTORE CLOUD WORKSPACE", style = MaterialTheme.typography.titleMedium, color = StudioPrimaryIndigo)
                        Text(
                            text = "User: ${cloudSession.displayName} ${if (cloudSession.email.isNotBlank()) "(${cloudSession.email})" else ""} • Provider: ${cloudSession.authMethod}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "Sync Status: $firestoreSyncStatus",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioEmeraldSuccess
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.signInWithGoogleAndSync(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo)
                            ) {
                                Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sign In with Google & Sync")
                            }
                            FilledTonalButton(
                                onClick = { viewModel.syncWorkspaceToFirestoreNow() }
                            ) {
                                Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sync Cloud Firestore")
                            }
                            if (cloudSession.isFirebaseConnected) {
                                OutlinedButton(onClick = { viewModel.signOutFirebase() }) {
                                    Text("Sign Out")
                                }
                            }
                        }
                    }
                }
            }

            // ADMIN ANALYTICS & ARCHITECTURE AUDIT
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ADMIN ANALYTICS & AI MODEL OBSERVABILITY", style = MaterialTheme.typography.titleMedium, color = StudioCyanAccent)
                        Text(
                            "Active Providers: Gemini 3.1 Pro, Veo 3.1 Fast, Gemini 3.1 Flash Image, Lyria 3 Clip & Pro, Gemini 3.5 Transcribe, Gemini 3.8 Live",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                        Text(
                            "Total Jobs Executed in Workspace: ${jobs.size} • Failed Jobs: ${jobs.count { it.status == "FAILED" }}",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioEmeraldSuccess
                        )
                        OutlinedButton(onClick = { viewModel.setArchitectureAuditOpen(true) }) {
                            Text("Inspect Global SaaS Architecture & Model Audit")
                        }
                    }
                }
            }
        }
    }
}

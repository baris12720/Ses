package com.example.ai

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

/** Saves generated audio/images to app storage so they can be played, previewed and shared. */
object GeneratedMediaStore {
    private fun dir(context: Context): File =
        File(context.filesDir, "generated").also { if (!it.exists()) it.mkdirs() }

    fun fileFor(context: Context, jobId: Long): File? =
        dir(context).listFiles()?.firstOrNull { it.nameWithoutExtension == "job_$jobId" && it.length() > 0 }

    fun mimeOf(file: File): String = when (file.extension.lowercase()) {
        "wav" -> "audio/wav"
        "mp3" -> "audio/mpeg"
        "ogg" -> "audio/ogg"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "mp4" -> "video/mp4"
        else -> "application/octet-stream"
    }

    fun isAudio(file: File) = mimeOf(file).startsWith("audio/")

    suspend fun save(context: Context, jobId: Long, base64: String?, mime: String): File? =
        withContext(Dispatchers.IO) {
            if (base64.isNullOrBlank()) return@withContext null
            try {
                var bytes = Base64.decode(base64, Base64.DEFAULT)
                val lower = mime.lowercase()
                val ext: String
                if (lower.contains("l16") || lower.contains("pcm")) {
                    val rate = Regex("rate=(\\d+)").find(lower)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                    val channels = Regex("channels=(\\d+)").find(lower)?.groupValues?.get(1)?.toIntOrNull() ?: 1
                    bytes = wrapPcmAsWav(bytes, rate, channels)
                    ext = "wav"
                } else {
                    ext = when {
                        lower.contains("wav") -> "wav"
                        lower.contains("mpeg") || lower.contains("mp3") -> "mp3"
                        lower.contains("ogg") -> "ogg"
                        lower.contains("png") -> "png"
                        lower.contains("jpeg") || lower.contains("jpg") -> "jpg"
                        lower.contains("webp") -> "webp"
                        else -> "bin"
                    }
                }
                val out = File(dir(context), "job_$jobId.$ext")
                out.writeBytes(bytes)
                out
            } catch (_: Exception) {
                null
            }
        }

    private fun wrapPcmAsWav(pcm: ByteArray, sampleRate: Int, channels: Int): ByteArray {
        val byteRate = sampleRate * channels * 2
        val out = ByteArrayOutputStream()
        fun int(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff); out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff) }
        fun short(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff) }
        out.write("RIFF".toByteArray()); int(36 + pcm.size)
        out.write("WAVE".toByteArray()); out.write("fmt ".toByteArray())
        int(16); short(1); short(channels); int(sampleRate); int(byteRate); short(channels * 2); short(16)
        out.write("data".toByteArray()); int(pcm.size)
        out.write(pcm)
        return out.toByteArray()
    }
}

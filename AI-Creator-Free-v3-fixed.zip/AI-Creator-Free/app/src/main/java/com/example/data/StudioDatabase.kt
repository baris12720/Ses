package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudioDao {
    // Projects
    @Query("SELECT * FROM projects WHERE isTrashed = 0 ORDER BY updatedAt DESC")
    fun getActiveProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE isTrashed = 1 ORDER BY updatedAt DESC")
    fun getTrashedProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProjectPermanently(projectId: Long)

    // Scenes
    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY sceneNumber ASC")
    fun getScenesForProject(projectId: Long): Flow<List<SceneEntity>>

    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY sceneNumber ASC")
    suspend fun getScenesForProjectSync(projectId: Long): List<SceneEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScene(scene: SceneEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Query("DELETE FROM scenes WHERE projectId = :projectId")
    suspend fun deleteScenesForProject(projectId: Long)

    @Query("DELETE FROM scenes WHERE id = :sceneId")
    suspend fun deleteSceneById(sceneId: Long)

    // Timeline Clips
    @Query("SELECT * FROM timeline_clips WHERE projectId = :projectId ORDER BY trackType ASC, startSec ASC")
    fun getClipsForProject(projectId: Long): Flow<List<TimelineClipEntity>>

    @Query("SELECT * FROM timeline_clips WHERE projectId = :projectId ORDER BY startSec ASC")
    suspend fun getClipsForProjectSync(projectId: Long): List<TimelineClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: TimelineClipEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClips(clips: List<TimelineClipEntity>)

    @Update
    suspend fun updateClip(clip: TimelineClipEntity)

    @Query("DELETE FROM timeline_clips WHERE id = :clipId")
    suspend fun deleteClipById(clipId: Long)

    @Query("DELETE FROM timeline_clips WHERE projectId = :projectId")
    suspend fun clearClipsForProject(projectId: Long)

    // Assets
    @Query("SELECT * FROM assets ORDER BY createdAt DESC")
    fun getAllAssets(): Flow<List<AssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: AssetEntity): Long

    @Update
    suspend fun updateAsset(asset: AssetEntity)

    @Query("DELETE FROM assets WHERE id = :assetId")
    suspend fun deleteAssetById(assetId: Long)

    // Generation Jobs
    @Query("SELECT * FROM generation_jobs ORDER BY createdAt DESC")
    fun getAllJobs(): Flow<List<GenerationJobEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: GenerationJobEntity): Long

    @Update
    suspend fun updateJob(job: GenerationJobEntity)

    // Characters
    @Query("SELECT * FROM character_profiles ORDER BY id ASC")
    fun getAllCharacters(): Flow<List<CharacterProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacter(character: CharacterProfileEntity): Long

    @Update
    suspend fun updateCharacter(character: CharacterProfileEntity)

    @Query("DELETE FROM character_profiles WHERE id = :id")
    suspend fun deleteCharacter(id: Long)

    // Brand Kits
    @Query("SELECT * FROM brand_kits ORDER BY id ASC")
    fun getAllBrandKits(): Flow<List<BrandKitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBrandKit(brandKit: BrandKitEntity): Long

    @Update
    suspend fun updateBrandKit(brandKit: BrandKitEntity)

    // Templates & Prompt Library
    @Query("SELECT * FROM prompt_templates ORDER BY id ASC")
    fun getAllTemplates(): Flow<List<PromptTemplateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: PromptTemplateEntity): Long

    @Update
    suspend fun updateTemplate(template: PromptTemplateEntity)

    // Project Versions
    @Query("SELECT * FROM project_versions WHERE projectId = :projectId ORDER BY versionNumber DESC")
    fun getVersionsForProject(projectId: Long): Flow<List<ProjectVersionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: ProjectVersionEntity): Long

    // Credits & Billing (Transaction-safe idempotency)
    @Query("SELECT * FROM credit_transactions ORDER BY createdAt DESC")
    fun getCreditTransactions(): Flow<List<CreditTransactionEntity>>

    @Query("SELECT * FROM credit_transactions WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getTransactionByKey(key: String): CreditTransactionEntity?

    @Query("SELECT balanceAfter FROM credit_transactions ORDER BY id DESC LIMIT 1")
    suspend fun getLatestCreditBalance(): Int?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCreditTransaction(tx: CreditTransactionEntity): Long

    @Transaction
    suspend fun recordCreditChangeSafely(
        idempotencyKey: String,
        description: String,
        deltaCredits: Int,
        planName: String
    ): Boolean {
        val existing = getTransactionByKey(idempotencyKey)
        if (existing != null) return false // Prevent duplicate charge for same generation job
        val currentBalance = getLatestCreditBalance() ?: 1250
        val newBalance = (currentBalance + deltaCredits).coerceAtLeast(0)
        insertCreditTransaction(
            CreditTransactionEntity(
                idempotencyKey = idempotencyKey,
                description = description,
                deltaCredits = deltaCredits,
                balanceAfter = newBalance,
                planName = planName
            )
        )
        return true
    }

    // Notifications
    @Query("SELECT * FROM studio_notifications ORDER BY createdAt DESC")
    fun getNotifications(): Flow<List<StudioNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: StudioNotificationEntity): Long

    @Query("UPDATE studio_notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationRead(id: Long)

    @Query("UPDATE studio_notifications SET isRead = 1")
    suspend fun markAllNotificationsRead()

    @Query("DELETE FROM studio_notifications WHERE id = :id")
    suspend fun deleteNotification(id: Long)
}

@Database(
    entities = [
        ProjectEntity::class,
        SceneEntity::class,
        TimelineClipEntity::class,
        AssetEntity::class,
        GenerationJobEntity::class,
        CharacterProfileEntity::class,
        BrandKitEntity::class,
        PromptTemplateEntity::class,
        ProjectVersionEntity::class,
        CreditTransactionEntity::class,
        StudioNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class StudioDatabase : RoomDatabase() {
    abstract fun studioDao(): StudioDao

    companion object {
        @Volatile
        private var INSTANCE: StudioDatabase? = null

        fun getInstance(context: Context): StudioDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudioDatabase::class.java,
                    "ai_creative_studio_v2.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

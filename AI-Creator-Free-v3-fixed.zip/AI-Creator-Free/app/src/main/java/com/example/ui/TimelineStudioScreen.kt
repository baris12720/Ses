package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ProjectEntity
import com.example.data.ProjectVersionEntity
import com.example.data.SceneEntity
import com.example.data.TimelineClipEntity
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun TimelineStudioScreen(
    viewModel: StudioViewModel,
    activeProject: ProjectEntity?,
    scenes: List<SceneEntity>,
    clips: List<TimelineClipEntity>,
    versions: List<ProjectVersionEntity>
) {
    val isPlaying by viewModel.isPlayingTimeline.collectAsState()
    val playheadSec by viewModel.playheadSec.collectAsState()
    val zoom by viewModel.timelineZoom.collectAsState()
    val selectedClipId by viewModel.selectedClipId.collectAsState()
    val viralAnalysis by viewModel.viralAnalysis.collectAsState()

    var inspectorTab by remember { mutableIntStateOf(0) } // 0: Keyframes, 1: Audio Mixer, 2: Subtitles, 3: Social/Versions
    var subtitleStyle by remember { mutableStateOf("Cinema") }
    var posX by remember { mutableFloatStateOf(0f) }
    var scaleVal by remember { mutableFloatStateOf(1.0f) }
    var rotationVal by remember { mutableFloatStateOf(0f) }
    var opacityVal by remember { mutableFloatStateOf(1.0f) }

    val selectedClip = clips.find { it.id == selectedClipId } ?: clips.firstOrNull()
    val currentScene = scenes.getOrNull((playheadSec / 5f).toInt().coerceIn(0, (scenes.size - 1).coerceAtLeast(0)))

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Studio Monitor Viewport + Transport Controls
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PROGRAM MONITOR • ${activeProject?.aspectRatio ?: "16:9"} (${activeProject?.resolution ?: "4K"} PROXY)",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioCyanAccent
                        )
                        Text(
                            text = "TC 00:00:${"%04.1f".format(playheadSec)} / 00:00:20.0",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioPrimaryBright
                        )
                    }

                    // Simulated Viewport Canvas with Active Scene, Safe Zones, Burned-in Subtitles & Watermark
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(176.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF07080C))
                            .border(1.dp, StudioPrimaryIndigo.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(14.dp)
                    ) {
                        // Top-left Scene & Camera HUD
                        Column(modifier = Modifier.align(Alignment.TopStart)) {
                            Text(
                                text = "SCENE 0${currentScene?.sceneNumber ?: 1} • ${currentScene?.cameraDirection ?: "Low Angle Tracking"} (${currentScene?.lens ?: "35mm"})",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioEmeraldSuccess
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentScene?.visualDescription ?: "Luxury vehicle & chronograph in rainy neon Tokyo",
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextPrimary,
                                maxLines = 2
                            )
                        }

                        // Top-right Watermark Badge (Section 60)
                        Surface(
                            color = StudioSurface.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.align(Alignment.TopEnd)
                        ) {
                            Text(
                                text = "CHRONOS // PRO MASTER",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Bottom Center Dynamic Subtitle Overlay (Section 20)
                        Surface(
                            color = if (subtitleStyle == "Karaoke" || subtitleStyle == "Social") StudioPrimaryIndigo else StudioObsidianBg.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.align(Alignment.BottomCenter)
                        ) {
                            Text(
                                text = "💬 [${subtitleStyle.uppercase()}] ${currentScene?.subtitleText ?: "Some journeys are measured in heartbeats, not hours."}",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // Playhead Scrubber Slider
                    Slider(
                        value = playheadSec,
                        onValueChange = { viewModel.setPlayhead(it) },
                        valueRange = 0f..20f,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("timeline_playhead_slider")
                    )

                    // Transport & Non-Linear Editing Toolbar (Section 14 & 33)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.toggleTimelinePlayback() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) StudioRoseDanger else StudioPrimaryIndigo
                            ),
                            modifier = Modifier.testTag("timeline_play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause (Space)"
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isPlaying) "Pause" else "Play")
                        }

                        OutlinedButton(
                            onClick = { viewModel.splitSelectedClipAtPlayhead() },
                            modifier = Modifier.testTag("timeline_split_button")
                        ) {
                            Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Split (S)")
                        }

                        OutlinedButton(
                            onClick = { viewModel.duplicateSelectedClip() },
                            modifier = Modifier.testTag("timeline_duplicate_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Duplicate")
                        }

                        OutlinedButton(
                            onClick = { viewModel.deleteSelectedClipWithRipple() },
                            modifier = Modifier.testTag("timeline_ripple_delete_button")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = StudioRoseDanger, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ripple Delete")
                        }

                        IconButton(onClick = { viewModel.undoTimelineAction() }) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo (Ctrl+Z)", tint = StudioTextPrimary)
                        }
                        IconButton(onClick = { viewModel.redoTimelineAction() }) {
                            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo (Ctrl+Shift+Z)", tint = StudioTextPrimary)
                        }
                        IconButton(onClick = { viewModel.adjustTimelineZoom(-0.2f) }) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = StudioTextSecondary)
                        }
                        IconButton(onClick = { viewModel.adjustTimelineZoom(0.2f) }) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = StudioTextSecondary)
                        }
                    }

                    // AI Smart Editing Bar: Auto Edit, Make It Viral, AI Audio Enhance (Section 16, 17, 18)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = { viewModel.runAutoEditor() },
                            modifier = Modifier.testTag("auto_edit_button")
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = StudioCyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Auto Edit (Silence + B-Roll + Beat Sync)")
                        }

                        FilledTonalButton(
                            onClick = { viewModel.analyzeProjectForViralMode() },
                            modifier = Modifier.testTag("make_it_viral_button")
                        ) {
                            Icon(Icons.Default.Whatshot, contentDescription = null, tint = StudioRoseDanger, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Make It Viral")
                        }

                        FilledTonalButton(
                            onClick = { viewModel.runAiAudioEnhance("Enhance Voice & Duck Music") },
                            modifier = Modifier.testTag("ai_audio_enhance_button")
                        ) {
                            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = StudioEmeraldSuccess, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("AI Audio Enhance")
                        }
                    }
                }
            }
        }

        // Section 18: Viral Mode Analysis & Apply Card (Analyze -> Preview Changes -> Apply)
        item {
            AnimatedVisibility(visible = viralAnalysis != null) {
                viralAnalysis?.let { analysis ->
                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, StudioRoseDanger, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🔥 VIRAL MODE ANALYSIS • HOOK SCORE ${analysis.hookScore}/100", style = MaterialTheme.typography.titleSmall, color = StudioRoseDanger)
                                Button(
                                    onClick = { viewModel.applyViralModeChanges() },
                                    colors = ButtonDefaults.buttonColors(containerColor = StudioRoseDanger),
                                    modifier = Modifier.testTag("apply_viral_changes_button")
                                ) {
                                    Text("Apply Viral Changes")
                                }
                            }
                            Text("Upgraded Hook: ${analysis.upgradedHook}", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                            Text("First 3s Optimization: ${analysis.first3SecOptimization}", style = MaterialTheme.typography.bodySmall, color = StudioCyanAccent)
                            Text("Pacing: ${analysis.pacingAdvice}", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                            analysis.bRollSuggestions.forEach { broll ->
                                Text("• Auto B-Roll: $broll", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                            }
                        }
                    }
                }
            }
        }

        // 2. 6-Track Synchronized Timeline Matrix (Section 14: VIDEO, IMAGE, VOICE, MUSIC, SFX, SUBTITLE)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("MULTI-TRACK TIMELINE (6 SYNCHRONIZED TRACKS • SNAP ENABLED)", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                        Text("Zoom: ${"%.1f".format(zoom)}x", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                    }

                    val trackOrder = listOf("VIDEO", "IMAGE", "VOICE", "MUSIC", "SFX", "SUBTITLE")
                    trackOrder.forEach { trackName ->
                        val trackClips = clips.filter { it.trackType == trackName }
                        val trackAccent = when (trackName) {
                            "VIDEO" -> StudioPrimaryIndigo
                            "IMAGE" -> Color(0xFF3B82F6)
                            "VOICE" -> StudioCyanAccent
                            "MUSIC" -> StudioEmeraldSuccess
                            "SFX" -> StudioAmberWarning
                            else -> StudioVioletSub
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(StudioObsidianBg, RoundedCornerShape(8.dp))
                                .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Track Header
                            Column(modifier = Modifier.width(76.dp)) {
                                Text(trackName, style = MaterialTheme.typography.labelMedium, color = trackAccent, fontWeight = FontWeight.Bold)
                                Text("${trackClips.size} clips", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                            }

                            // Horizontal Clips Lane
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                trackClips.forEach { clip ->
                                    val isSelected = clip.id == selectedClip?.id
                                    val widthDp = ((clip.durationSec * 22f * zoom).coerceIn(72f, 280f)).dp
                                    Surface(
                                        color = trackAccent.copy(alpha = if (clip.isMuted) 0.12f else 0.28f),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier
                                            .width(widthDp)
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color.White else trackAccent,
                                                shape = RoundedCornerShape(6.dp)
                                            )
                                            .clickable { viewModel.selectClip(clip.id) }
                                    ) {
                                        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                                            Text(
                                                text = clip.label,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = StudioTextPrimary,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${"%.1f".format(clip.startSec)}s–${"%.1f".format(clip.startSec + clip.durationSec)}s",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = StudioTextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Inspector Panel: Keyframes, Audio Mixing, Automatic Subtitles & Social Repurpose (Sections 15, 16, 20, 21, 54)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TabRow(
                        selectedTabIndex = inspectorTab,
                        containerColor = StudioSurfaceElevated,
                        contentColor = StudioPrimaryBright
                    ) {
                        Tab(selected = inspectorTab == 0, onClick = { inspectorTab = 0 }, text = { Text("Keyframes") })
                        Tab(selected = inspectorTab == 1, onClick = { inspectorTab = 1 }, text = { Text("Audio Mixer") })
                        Tab(selected = inspectorTab == 2, onClick = { inspectorTab = 2 }, text = { Text("Subtitles") })
                        Tab(selected = inspectorTab == 3, onClick = { inspectorTab = 3 }, text = { Text("Repurpose & History") })
                    }

                    when (inspectorTab) {
                        0 -> {
                            // Section 15: Keyframes & Clip Trim Controls
                            Text(
                                text = "KEYFRAME INSPECTOR • ${selectedClip?.label ?: "Select a clip"}",
                                style = MaterialTheme.typography.titleSmall,
                                color = StudioTextPrimary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { viewModel.nudgeSelectedClip(-0.5f, 0f) }) { Text("Move -0.5s") }
                                OutlinedButton(onClick = { viewModel.nudgeSelectedClip(0.5f, 0f) }) { Text("Move +0.5s") }
                                OutlinedButton(onClick = { viewModel.nudgeSelectedClip(0f, 1.0f) }) { Text("Trim +1s") }
                            }
                            Text("Position X: ${posX.toInt()}px • Scale: ${"%.2f".format(scaleVal)}x • Rotation: ${rotationVal.toInt()}° • Opacity: ${(opacityVal * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                            Slider(value = scaleVal, onValueChange = { scaleVal = it }, valueRange = 0.5f..2.0f)
                            Slider(value = opacityVal, onValueChange = { opacityVal = it }, valueRange = 0.1f..1.0f)
                            Button(
                                onClick = {
                                    selectedClip?.let {
                                        viewModel.updateClipAudioMix(
                                            clip = it,
                                            keyframeData = "Pos(${posX.toInt()},0) Scale(${"%.2f".format(scaleVal)}) Rot(${rotationVal.toInt()}°) Opacity(${(opacityVal * 100).toInt()}%)"
                                        )
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Insert Keyframe at Playhead")
                            }
                        }

                        1 -> {
                            // Section 16: Audio Mixing & AI Audio Enhance
                            selectedClip?.let { clip ->
                                var vol by remember(clip) { mutableFloatStateOf(clip.volume) }
                                var pan by remember(clip) { mutableFloatStateOf(clip.pan) }
                                Text("CHANNEL STRIP • ${clip.label}", style = MaterialTheme.typography.titleSmall, color = StudioEmeraldSuccess)
                                Text("Volume: ${(vol * 100).toInt()}% • Pan: ${"%.2f".format(pan)} • Fade In: ${clip.fadeInSec}s • Fade Out: ${clip.fadeOutSec}s", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                                Slider(
                                    value = vol,
                                    onValueChange = {
                                        vol = it
                                        viewModel.updateClipAudioMix(clip, volume = it)
                                    },
                                    valueRange = 0f..1.5f
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = clip.isMuted,
                                        onClick = { viewModel.updateClipAudioMix(clip, isMuted = !clip.isMuted) },
                                        label = { Text("Mute") }
                                    )
                                    FilterChip(
                                        selected = clip.isSolo,
                                        onClick = { viewModel.updateClipAudioMix(clip, isSolo = !clip.isSolo) },
                                        label = { Text("Solo") }
                                    )
                                    AssistChip(
                                        onClick = { viewModel.runAiAudioEnhance("Normalize -14 LUFS + Compressor + EQ") },
                                        label = { Text("Normalize + Compressor + EQ") }
                                    )
                                }
                            }
                        }

                        2 -> {
                            // Section 20: Automatic Subtitles
                            Text("AUTOMATIC SUBTITLES (WORD-LEVEL TIMING & SPEAKER DETECTION)", style = MaterialTheme.typography.titleSmall, color = StudioVioletSub)
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Minimal", "Bold", "Cinema", "Karaoke", "Modern", "Social", "News").forEach { st ->
                                    FilterChip(
                                        selected = subtitleStyle == st,
                                        onClick = { subtitleStyle = st },
                                        label = { Text(st) }
                                    )
                                }
                            }
                            Text(
                                text = "Features active: Word-level timestamps • Speaker ID • Auto Punctuation • Emoji & Keyword Highlighting.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.launchModalityGeneration(
                                            jobType = "EXPORT",
                                            title = "Subtitles Export ($subtitleStyle)",
                                            prompt = "Export word-level captions in SRT & VTT",
                                            resolutionOrFormat = "SRT + VTT + Burned-in",
                                            durationSec = 20,
                                            creditCost = 1
                                        )
                                    }
                                ) {
                                    Text("Export SRT / VTT")
                                }
                            }
                        }

                        3 -> {
                            // Section 21: Social Media Repurpose & Section 54: Version History
                            Text("ONE-CLICK SOCIAL MEDIA REPURPOSE (AI SUBJECT TRACKING)", style = MaterialTheme.typography.titleSmall, color = StudioCyanAccent)
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(
                                    "YouTube (16:9)" to "16:9",
                                    "TikTok (9:16)" to "9:16",
                                    "Instagram Reels (9:16)" to "9:16",
                                    "YouTube Shorts (9:16)" to "9:16"
                                ).forEach { (platform, ratio) ->
                                    FilledTonalButton(
                                        onClick = { viewModel.repurposeProjectForSocial(platform, ratio) }
                                    ) {
                                        Text(platform)
                                    }
                                }
                            }
                            HorizontalDivider(color = StudioBorderSubtle)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("VERSION HISTORY (NON-DESTRUCTIVE SNAPSHOTS)", style = MaterialTheme.typography.labelMedium, color = StudioPrimaryBright)
                                TextButton(onClick = { viewModel.createManualVersionSnapshot("Timeline Checkpoint") }) {
                                    Text("+ Save Snapshot")
                                }
                            }
                            versions.take(4).forEach { ver ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(ver.label, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                        Text(ver.summary, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                                    }
                                    TextButton(onClick = { viewModel.restoreProjectVersion(ver) }) {
                                        Text("Restore")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.example.ai

import android.content.Context
import android.util.Base64
import com.example.BuildConfig
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

/** Stores BYOK secrets encrypted with an Android Keystore AES-256 key. */
object ApiKeyStore {
    private const val PREFS = "studio_secure_prefs"
    private const val KEY_USER = "user_gemini_api_key"
    private const val KEY_ALIAS = "ai_creative_studio_api_key"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private var appContext: Context? = null

    var hasUserKey = false
        private set

    val hasBuildKey: Boolean
        get() = BuildConfig.GEMINI_API_KEY.let { it.isNotBlank() && it != "MY_GEMINI_API_KEY" }

    fun init(context: Context) {
        appContext = context.applicationContext
        hasUserKey = !readUserKey().isNullOrBlank()
    }

    private fun prefs() = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance("AES", ANDROID_KEYSTORE)
        generator.init(256)
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val combined = cipher.iv + cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String? = runCatching {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        require(bytes.size > 12)
        val iv = bytes.copyOfRange(0, 12)
        val payload = bytes.copyOfRange(12, bytes.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(payload), StandardCharsets.UTF_8)
    }.getOrNull()

    private fun readUserKey(): String? {
        val encrypted = prefs()?.getString(KEY_USER, null) ?: return null
        return decrypt(encrypted)
    }

    fun saveUserKey(key: String) {
        val clean = key.trim()
        if (clean.isBlank()) {
            clearUserKey()
            return
        }
        prefs()?.edit()?.putString(KEY_USER, encrypt(clean))?.apply()
        hasUserKey = true
    }

    fun clearUserKey() {
        prefs()?.edit()?.remove(KEY_USER)?.apply()
        hasUserKey = false
    }

    fun effectiveKey(): String? = readUserKey()?.takeIf { it.isNotBlank() }
        ?: BuildConfig.GEMINI_API_KEY.takeIf { hasBuildKey }
}

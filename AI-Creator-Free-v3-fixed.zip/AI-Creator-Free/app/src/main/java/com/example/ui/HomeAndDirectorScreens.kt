package com.example.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.*
import com.example.i18n.LocalStudioLocalizer
import com.example.i18n.StudioExperienceMode
import com.example.i18n.StudioLanguage
import com.example.ui.theme.*
import com.example.viewmodel.StudioDestination
import com.example.viewmodel.StudioViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeDashboardScreen(
    viewModel: StudioViewModel,
    projects: List<ProjectEntity>,
    jobs: List<GenerationJobEntity>,
    templates: List<PromptTemplateEntity>,
    assets: List<AssetEntity>,
    credits: Int,
    planName: String
) {
    val i18n = LocalStudioLocalizer.current
    val heroPrompt by viewModel.heroPrompt.collectAsState()
    val enhancedPrompt by viewModel.enhancedPromptPreview.collectAsState()
    val selectedTier by viewModel.selectedModelTier.collectAsState()
    val showAdvanced by viewModel.showAdvancedModelControls.collectAsState()
    val experienceMode by viewModel.experienceMode.collectAsState()
    val isRecordingMic by viewModel.isRecordingMic.collectAsState()
    val searchGrounding by viewModel.searchGroundingResult.collectAsState()
    val homeLang by viewModel.selectedLanguage.collectAsState()
    val isTr = homeLang.code == "tr"

    var selectedDuration by remember { mutableIntStateOf(30) }
    var selectedAspectRatio by remember { mutableStateOf("16:9") }
    var selectedResolution by remember { mutableStateOf("1080p") }
    var cfgScale by remember { mutableFloatStateOf(7.5f) }
    var stepsCount by remember { mutableIntStateOf(32) }
    var seedValue by remember { mutableStateOf("84920411") }
    var showGlobalShowcase by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.recordAndTranscribeMicrophone()
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        viewModel.onPhotoSelectedFromPicker(uri)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // 0. Modern greeting, Text-to-Song spotlight and prompt ideas
        item {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Column {
                    Text(
                        text = if (isTr) "Merhaba 👋" else "Hello 👋",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudioTextSecondary
                    )
                    Text(
                        text = if (isTr) "Bugün ne yaratalım?" else "What shall we create today?",
                        style = MaterialTheme.typography.headlineMedium,
                        color = StudioTextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(StudioPrimaryIndigo, StudioVioletSub)))
                        .clickable { viewModel.navigateTo(StudioDestination.MUSIC) }
                        .testTag("text_to_song_banner")
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isTr) "YENİ" else "NEW",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = if (isTr) "Metinden Şarkı" else "Text to Song",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White
                            )
                            Text(
                                text = if (isTr) "Metnini yaz, türü seç, yapay zeka bestelesin ve seslendirsin."
                                else "Write your text, pick a genre, let AI compose and sing it.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Icon(
                            imageVector = Icons.Default.Lyrics,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                val promptIdeas = if (isTr) listOf(
                    "Yağmurlu neon Tokyo'da lüks saat reklamı",
                    "Sahilde gün batımı, sakin akustik şarkı",
                    "Fütüristik şehirde 9:16 sosyal medya videosu",
                    "Kahve markası için sinematik tanıtım"
                ) else listOf(
                    "Luxury watch ad in rainy neon Tokyo",
                    "Calm acoustic song at sunset on the beach",
                    "9:16 social video in a futuristic city",
                    "Cinematic promo for a coffee brand"
                )
                Text(
                    text = if (isTr) "İLHAM" else "IDEAS",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioTextSecondary
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(promptIdeas) { idea ->
                        AssistChip(
                            onClick = { viewModel.updateHeroPrompt(idea) },
                            label = { Text(idea, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingIcon = {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = StudioPrimaryBright, modifier = Modifier.size(16.dp))
                            }
                        )
                    }
                }
            }
        }

        item { ApiKeyCard(isTr = isTr) }
        item { ResultsShelf(jobs = jobs, isTr = isTr) }

        // 1. Global SaaS Hero Command Center (Sections 3, 4, 8, 75)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(16.dp))
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(172.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_studio_hero),
                            contentDescription = "AI Creative Studio Hero",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            StudioObsidianBg.copy(alpha = 0.20f),
                                            StudioSurface
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = StudioPrimaryContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "VEO 3.1 • LYRIA 3 • GEMINI",
                                        maxLines = 1,
                                        softWrap = false,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioPrimaryBright,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Surface(
                                    color = StudioSurfaceElevated,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable { showGlobalShowcase = !showGlobalShowcase }
                                ) {
                                    Text(
                                        text = if (showGlobalShowcase) "Hide Global Tour" else i18n.t("landing.exploreStudio"),
                                        maxLines = 1,
                                        softWrap = false,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioCyanAccent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = i18n.t("landing.heroTitle"),
                                style = MaterialTheme.typography.headlineLarge,
                                color = StudioTextPrimary
                            )
                            Text(
                                text = i18n.t("landing.heroSubtitle"),
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary,
                                maxLines = 2
                            )
                        }
                    }

                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = heroPrompt,
                            onValueChange = { viewModel.updateHeroPrompt(it) },
                            label = { Text(i18n.t("dashboard.promptPlaceholder")) },
                            trailingIcon = {
                                IconButton(
                                    onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                                    modifier = Modifier.testTag("hero_mic_transcribe_button")
                                ) {
                                    Icon(
                                        imageVector = if (isRecordingMic) Icons.Default.GraphicEq else Icons.Default.Mic,
                                        contentDescription = "Transcribe Audio (gemini-3.5-transcribe)",
                                        tint = if (isRecordingMic) StudioRoseDanger else StudioCyanAccent
                                    )
                                }
                            },
                            minLines = 2,
                            maxLines = 4,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("hero_prompt_input")
                        )

                        // Section 8: Attachment & Grounding Bar (Attach Image, Video, Audio, Brand, Reference + Google Search Grounding)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AssistChip(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                label = { Text("Attach Image / Photo") },
                                leadingIcon = { Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = StudioCyanAccent, modifier = Modifier.size(16.dp)) },
                                modifier = Modifier.testTag("attach_photo_chip")
                            )
                            AssistChip(
                                onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                                label = { Text(if (isRecordingMic) "Transcribing..." else "Voice Dictation (3.5 Transcribe)") },
                                leadingIcon = { Icon(Icons.Default.Mic, contentDescription = null, tint = StudioEmeraldSuccess, modifier = Modifier.size(16.dp)) }
                            )
                            AssistChip(
                                onClick = { viewModel.runGoogleSearchGrounding(heroPrompt) },
                                label = { Text("Google Search Grounding") },
                                leadingIcon = { Icon(Icons.Default.TravelExplore, contentDescription = null, tint = StudioPrimaryBright, modifier = Modifier.size(16.dp)) },
                                modifier = Modifier.testTag("google_search_grounding_chip")
                            )
                            AssistChip(
                                onClick = { viewModel.navigateTo(StudioDestination.BRAND_KIT) },
                                label = { Text("Brand Kit Lock") },
                                leadingIcon = { Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            )
                        }

                        // Google Search Grounding Live Results Box (`gemini-3.5-flash` + `googleSearch`)
                        AnimatedVisibility(visible = searchGrounding != null) {
                            searchGrounding?.let { grounding ->
                                Surface(
                                    color = StudioSurfaceElevated,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, StudioEmeraldSuccess.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = "GOOGLE SEARCH GROUNDING (GEMINI-3.5-FLASH + GOOGLESEARCH)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StudioEmeraldSuccess
                                        )
                                        Text(grounding.summary, style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                                        grounding.sources.forEach { src ->
                                            Text("• ${src.title} (${src.url})", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                                        }
                                    }
                                }
                            }
                        }

                        // Prompt Enhancer Comparison Box (Section 30)
                        AnimatedVisibility(visible = enhancedPrompt.isNotBlank()) {
                            Surface(
                                color = StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, StudioCyanAccent.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "AI ENHANCED PRODUCTION PROMPT",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StudioCyanAccent
                                        )
                                        TextButton(
                                            onClick = { viewModel.applyEnhancedPrompt() },
                                            modifier = Modifier.testTag("apply_enhanced_prompt_button")
                                        ) {
                                            Text(i18n.t("common.apply"), color = StudioPrimaryBright)
                                        }
                                    }
                                    Text(
                                        text = enhancedPrompt,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = StudioTextPrimary
                                    )
                                }
                            }
                        }

                        // Model Selector & Progressive Disclosure (Section 29 & 48)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("Fast", "Balanced", "Quality", "Cinematic").forEach { tier ->
                                FilterChip(
                                    selected = selectedTier == tier,
                                    onClick = { viewModel.setModelTier(tier) },
                                    label = { Text(tier) },
                                    leadingIcon = if (selectedTier == tier) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(15.dp)) }
                                    } else null
                                )
                            }
                            AssistChip(
                                onClick = { viewModel.enhanceCurrentPrompt() },
                                label = { Text(i18n.t("common.enhance")) },
                                leadingIcon = {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = StudioCyanAccent, modifier = Modifier.size(16.dp))
                                },
                                modifier = Modifier.testTag("enhance_prompt_button")
                            )
                            if (experienceMode != StudioExperienceMode.BEGINNER) {
                                AssistChip(
                                    onClick = { viewModel.toggleAdvancedModelControls() },
                                    label = { Text(if (showAdvanced) "Hide Advanced" else "Pro Controls") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                )
                            }
                        }

                        // Collapsible Advanced Model Controls (Section 29 & 48)
                        AnimatedVisibility(visible = showAdvanced && experienceMode != StudioExperienceMode.BEGINNER) {
                            Surface(
                                color = StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(10.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "PRO MODEL & VEO 3.1 RENDER PARAMETERS (16:9 / 9:16)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioTextMuted
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("16:9", "9:16", "1:1", "4:5").forEach { ratio ->
                                            FilterChip(
                                                selected = selectedAspectRatio == ratio,
                                                onClick = { selectedAspectRatio = ratio },
                                                label = { Text(ratio) }
                                            )
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("720p", "1080p", "4K").forEach { res ->
                                            FilterChip(
                                                selected = selectedResolution == res,
                                                onClick = { selectedResolution = res },
                                                label = { Text(res) }
                                            )
                                        }
                                        listOf(15, 30, 60).forEach { dur ->
                                            FilterChip(
                                                selected = selectedDuration == dur,
                                                onClick = { selectedDuration = dur },
                                                label = { Text("${dur}s") }
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Steps: $stepsCount • CFG: ${"%.1f".format(cfgScale)} • Seed: $seedValue",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = StudioCyanAccent
                                    )
                                }
                            }
                        }

                        // Primary CTAs (Section 3: Start Creating / Explore Studio / Watch Demo)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.runOneClickCompleteVideo(
                                        prompt = heroPrompt,
                                        durationSec = selectedDuration,
                                        aspectRatio = selectedAspectRatio,
                                        resolution = selectedResolution
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("create_complete_video_cta")
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(i18n.t("landing.startCreating"), fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    viewModel.generateCreativeBriefFirst(heroPrompt)
                                    viewModel.navigateTo(StudioDestination.AI_DIRECTOR)
                                },
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("open_ai_director_cta")
                            ) {
                                Icon(Icons.Default.MovieFilter, contentDescription = null, tint = StudioCyanAccent)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(i18n.t("nav.ai_director"))
                            }

                            OutlinedButton(
                                onClick = {
                                    viewModel.navigateTo(StudioDestination.STUDIO)
                                    viewModel.toggleTimelinePlayback()
                                },
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("watch_demo_cta")
                            ) {
                                Icon(Icons.Default.PlayCircle, contentDescription = null, tint = StudioEmeraldSuccess)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(i18n.t("landing.watchDemo"))
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Global Platform Showcase (Trusted By, 19 Global Languages, FAQ & Footer)
        item {
            AnimatedVisibility(visible = showGlobalShowcase) {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioPrimaryIndigo.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("TRUSTED BY GLOBAL CREATIVE TEAMS & STUDIOS IN 19 LANGUAGES", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                        Text(
                            text = "Supported Native Locales (Including True RTL): " +
                                StudioLanguage.entries.joinToString(" • ") { it.nativeName },
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "Integrated AI Suite: Veo 3.1 Fast (16:9 & 9:16 Video + Photo Animation) • Gemini 3.1 Flash Image (Create & Edit) • Lyria 3 (Clip <=30s & Pro Full-Length Music) • Gemini 3.5 Transcribe (Mic Audio) • Gemini 3.8 Live (Real-Time Voice) • Gemini 3.5 Flash Google Search Grounding • Firebase Auth & Cloud Firestore.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioEmeraldSuccess
                        )
                    }
                }
            }
        }

        // 2. 8 Quick Action Creation Buttons (Section 3)
        item {
            Text(
                text = "QUICK STUDIO WORKFLOWS",
                style = MaterialTheme.typography.labelMedium,
                color = StudioTextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            val quickButtons = listOf(
                Triple(if (isTr) "Metinden Şarkı" else "Text to Song", Icons.Default.Lyrics, StudioDestination.MUSIC),
                Triple(i18n.t("common.createVideo"), Icons.Default.Videocam, StudioDestination.VIDEO),
                Triple(i18n.t("cmd.createVoice"), Icons.Default.RecordVoiceOver, StudioDestination.VOICE),
                Triple(i18n.t("cmd.createMusic"), Icons.Default.LibraryMusic, StudioDestination.MUSIC),
                Triple("Create & Edit Image", Icons.Default.Image, StudioDestination.IMAGE),
                Triple("Create Ad (Brief)", Icons.Default.Campaign, StudioDestination.AI_DIRECTOR),
                Triple("Social 9:16 Video", Icons.Default.Smartphone, StudioDestination.STUDIO),
                Triple("Live Voice 3.8", Icons.Default.Podcasts, StudioDestination.VOICE),
                Triple("Cloud & Languages", Icons.Default.Language, StudioDestination.SETTINGS)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(quickButtons) { item ->
                    val (label, icon, targetDest) = item
                    Column(
                        modifier = Modifier
                            .width(116.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(StudioSurface)
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                            .clickable { viewModel.navigateTo(targetDest) }
                            .testTag("quick_btn_${label.lowercase().replace(" ", "_")}")
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(StudioPrimaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icon, contentDescription = null, tint = StudioPrimaryBright, modifier = Modifier.size(22.dp))
                        }
                        Text(
                            text = label,
                            style = MaterialTheme.typography.titleSmall,
                            color = StudioTextPrimary,
                            minLines = 2,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // 3. Credits, Usage & Rendering Jobs Row (Section 3, 26, 40)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("CREDITS & USAGE", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$credits Credits", style = MaterialTheme.typography.headlineMedium, color = StudioTextPrimary)
                        Text(
                            text = "$planName • ${projects.size} Projects • ${assets.size} Assets",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                    }
                }

                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
                ) {
                    val latestJob = jobs.firstOrNull()
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("RENDERING JOBS QUEUE", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = latestJob?.title ?: "Queue Idle",
                            style = MaterialTheme.typography.titleSmall,
                            color = StudioTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${latestJob?.stageMessage ?: "Ready"} (${latestJob?.progressPercent ?: 100}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // 4. Recent Projects (Section 3 & 24)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(i18n.t("dashboard.recentProjects").uppercase(), style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                TextButton(onClick = { viewModel.navigateTo(StudioDestination.PROJECTS) }) {
                    Text("View All (${projects.size})")
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(projects, key = { it.id }) { proj ->
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .width(270.dp)
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectActiveProject(proj.id) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                                    Text(
                                        text = "${proj.aspectRatio} • ${proj.resolution}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioPrimaryBright,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = "${proj.totalDurationSec}s • v${proj.currentVersion}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioEmeraldSuccess
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = proj.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = StudioTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = proj.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // 5. Featured Templates & Favorites (Section 3, 23, 35)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("GLOBAL PROMPT TEMPLATES & FAVORITES", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                TextButton(onClick = { viewModel.navigateTo(StudioDestination.TEMPLATES) }) {
                    Text("Marketplace")
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(templates, key = { it.id }) { tmpl ->
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .width(240.dp)
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
                            .clickable { viewModel.useTemplateInDirector(tmpl) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(tmpl.category.uppercase(), style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                                if (tmpl.isFavorite) {
                                    Icon(Icons.Default.Star, contentDescription = "Favorite", tint = StudioAmberWarning, modifier = Modifier.size(15.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(tmpl.title, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary, maxLines = 1)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(tmpl.previewStyle, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiDirectorScreen(
    viewModel: StudioViewModel,
    activeProject: ProjectEntity?,
    scenes: List<SceneEntity>,
    characters: List<CharacterProfileEntity>
) {
    val i18n = LocalStudioLocalizer.current
    val heroPrompt by viewModel.heroPrompt.collectAsState()
    val creativeBrief by viewModel.creativeBrief.collectAsState()
    val promptLang by viewModel.promptInputLanguage.collectAsState()
    val outputLang by viewModel.outputTargetLanguage.collectAsState()
    val searchGrounding by viewModel.searchGroundingResult.collectAsState()
    val dubbingResult by viewModel.lastDubbingResult.collectAsState()
    var editingScene by remember { mutableStateOf<SceneEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // AI Director Command Header (Sections 8, 9, 22, 64)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = StudioCyanAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI DIRECTOR • LANGUAGE-AWARE CREATIVE ORCHESTRATOR", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        }
                        Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "${scenes.size} SCENES",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioPrimaryBright,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Section 22: Prompt Language -> Output Language Selector
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Output Language:", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                        listOf("English", "Türkçe", "Deutsch", "Français", "Español", "العربية", "日本語").forEach { lang ->
                            FilterChip(
                                selected = outputLang == lang,
                                onClick = { viewModel.setPromptAndOutputLanguages(promptLang, lang) },
                                label = { Text(lang) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = heroPrompt,
                        onValueChange = { viewModel.updateHeroPrompt(it) },
                        label = { Text(i18n.t("dashboard.promptPlaceholder")) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("director_prompt_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.generateCreativeBriefFirst(heroPrompt) },
                            modifier = Modifier.testTag("director_build_brief_button")
                        ) {
                            Icon(Icons.Default.Assignment, contentDescription = null, tint = StudioCyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("1. Creative Brief")
                        }
                        OutlinedButton(
                            onClick = { viewModel.runGoogleSearchGrounding(heroPrompt) },
                            modifier = Modifier.testTag("director_search_grounding_button")
                        ) {
                            Icon(Icons.Default.TravelExplore, contentDescription = null, tint = StudioEmeraldSuccess, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Search Grounding")
                        }
                        Button(
                            onClick = { viewModel.runOneClickCompleteVideo(prompt = heroPrompt) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("director_generate_plan_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Generate Plan")
                        }
                    }
                }
            }
        }

        // Section 9: Editable Creative Brief Card
        creativeBrief?.let { brief ->
            item {
                Surface(
                    color = StudioSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioCyanAccent.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SECTION 9: INTERACTIVE CREATIVE BRIEF (PRE-PRODUCTION)", style = MaterialTheme.typography.titleSmall, color = StudioCyanAccent)
                        DirectorInfoRow("Project", brief.projectName)
                        DirectorInfoRow("Goal", brief.goal)
                        DirectorInfoRow("Audience", brief.audience)
                        DirectorInfoRow("Duration & Platform", "${brief.durationSec}s • ${brief.platform}")
                        DirectorInfoRow("Language Flow", "${brief.promptLanguage} → ${brief.outputLanguage}")
                        DirectorInfoRow("Voice & Music", "${brief.voiceProfile} • ${brief.musicDirection}")
                        DirectorInfoRow("Visual Style", brief.visualStyle)
                    }
                }
            }
        }

        // Google Search Grounding Sources if present
        searchGrounding?.let { grounding ->
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioEmeraldSuccess.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("GOOGLE SEARCH GROUNDING INSIGHTS (GEMINI-3.5-FLASH)", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                        Text(grounding.summary, style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                    }
                }
            }
        }

        // 16-Point Director Blueprint + Multilingual Dubbing Trigger (Sections 4, 23, 24, 38)
        if (activeProject != null) {
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("PRODUCTION BLUEPRINT — ${activeProject.title.uppercase()}", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                        DirectorInfoRow("1. Concept", activeProject.concept)
                        DirectorInfoRow("2. Target Audience", activeProject.targetAudience)
                        DirectorInfoRow("3. Opening Hook (0–3s)", activeProject.hook)
                        DirectorInfoRow("4. Call To Action (CTA)", activeProject.cta)
                        DirectorInfoRow("5. Format & Spec", "${activeProject.aspectRatio} • ${activeProject.resolution} • ${activeProject.fps}fps • ${activeProject.totalDurationSec}s")

                        HorizontalDivider(color = StudioBorderSubtle, modifier = Modifier.padding(vertical = 4.dp))

                        // Sections 23, 24, 38: One-Click Multilingual Translate & AI Dubbing
                        Text("MULTILINGUAL VIDEO DUBBING & CULTURAL LOCALIZATION", style = MaterialTheme.typography.labelSmall, color = StudioPrimaryBright)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Turkish", "German", "French", "Spanish", "Arabic", "Japanese").forEach { targetLang ->
                                AssistChip(
                                    onClick = { viewModel.runAiTranslateAndDub(activeProject.script, targetLang) },
                                    label = { Text("${i18n.t("common.translate")} & Dub → $targetLang") },
                                    leadingIcon = { Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(15.dp)) }
                                )
                            }
                        }

                        dubbingResult?.let { dub ->
                            Surface(
                                color = StudioSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("AI Dub (${dub.sourceLanguage} → ${dub.targetLanguage})", style = MaterialTheme.typography.labelMedium, color = StudioEmeraldSuccess)
                                    Text(dub.translatedScript, style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                                    Text(dub.timingAlignmentNote, style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                                }
                            }
                        }

                        HorizontalDivider(color = StudioBorderSubtle, modifier = Modifier.padding(vertical = 4.dp))

                        // Section 7: Style Lock Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "STYLE LOCK: \"Use this visual style for the entire project\"",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = StudioTextPrimary
                                )
                                Text(
                                    text = "${activeProject.styleReferenceName} • ${activeProject.styleColorPalette} • ${activeProject.styleLighting}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StudioTextSecondary
                                )
                            }
                            Switch(
                                checked = activeProject.styleLockEnabled,
                                onCheckedChange = { viewModel.toggleProjectStyleLock(activeProject) },
                                modifier = Modifier.testTag("style_lock_switch")
                            )
                        }
                    }
                }
            }
        }

        // Character Consistency Bar (Section 6)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("CHARACTER CONSISTENCY LOCK (ACTIVE CAST)", style = MaterialTheme.typography.labelSmall, color = StudioPrimaryBright)
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(characters, key = { it.id }) { charProfile ->
                            Surface(
                                color = StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.border(1.dp, StudioPrimaryIndigo.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            ) {
                                Column(modifier = Modifier.padding(10.dp).width(210.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(charProfile.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                        Text("LOCKED", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                                    }
                                    Text("${charProfile.age} yrs • ${charProfile.appearance}", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary, maxLines = 1)
                                    Text("Wardrobe: ${charProfile.clothes}", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Scene Cards Header + Add Scene (Section 10)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("STORYBOARD & SCENE BREAKDOWN (REORDERABLE & NON-DESTRUCTIVE)", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                OutlinedButton(
                    onClick = { viewModel.addNewSceneToActiveProject() },
                    modifier = Modifier.testTag("add_scene_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Scene")
                }
            }
        }

        // Individual Editable & Reorderable Scene Cards (Section 10)
        items(scenes, key = { it.id }) { scene ->
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = StudioPrimaryIndigo, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = "SCENE 0${scene.sceneNumber}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Duration: ${scene.durationSec} sec • ${scene.lens} Lens",
                                style = MaterialTheme.typography.labelMedium,
                                color = StudioCyanAccent
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.reorderScene(scene, moveUp = true) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.ArrowUpward, contentDescription = "Move Scene Up", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = { viewModel.reorderScene(scene, moveUp = false) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.ArrowDownward, contentDescription = "Move Scene Down", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                            }
                            TextButton(
                                onClick = { editingScene = scene },
                                modifier = Modifier.testTag("edit_scene_${scene.sceneNumber}_button")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Edit")
                            }
                        }
                    }

                    DirectorInfoRow("Visual", scene.visualDescription)
                    DirectorInfoRow("Camera", "${scene.cameraDirection} (${scene.lens})")
                    DirectorInfoRow("Lighting", scene.lighting)
                    DirectorInfoRow("Voice-Over", "\"${scene.voiceScript}\"")
                    DirectorInfoRow("Music & SFX", "${scene.musicPrompt} • SFX: ${scene.sfxPrompt}")
                    DirectorInfoRow("Subtitle", scene.subtitleText)

                    // Section 10 & 67: Non-Destructive Variant & Duration Actions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            1 to "Original Scene",
                            2 to "AI Version",
                            3 to "Alt Angle"
                        ).forEach { (idx, label) ->
                            FilterChip(
                                selected = scene.selectedVariant == idx,
                                onClick = { viewModel.selectSceneVariant(scene, idx) },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                        AssistChip(
                            onClick = {
                                viewModel.updateSceneDetails(
                                    scene = scene,
                                    newVisual = scene.visualDescription,
                                    newVoice = scene.voiceScript,
                                    newCamera = scene.cameraDirection,
                                    newLighting = scene.lighting,
                                    newDuration = scene.durationSec + 2
                                )
                            },
                            label = { Text("Extend +2s") }
                        )
                        AssistChip(
                            onClick = {
                                viewModel.updateSceneDetails(
                                    scene = scene,
                                    newVisual = scene.visualDescription,
                                    newVoice = scene.voiceScript,
                                    newCamera = scene.cameraDirection,
                                    newLighting = scene.lighting,
                                    newDuration = (scene.durationSec - 1).coerceAtLeast(2)
                                )
                            },
                            label = { Text("Shorten -1s") }
                        )
                    }
                }
            }
        }
    }

    // Scene Inline Edit Dialog
    editingScene?.let { targetScene ->
        var visual by remember(targetScene) { mutableStateOf(targetScene.visualDescription) }
        var voice by remember(targetScene) { mutableStateOf(targetScene.voiceScript) }
        var camera by remember(targetScene) { mutableStateOf(targetScene.cameraDirection) }
        var lighting by remember(targetScene) { mutableStateOf(targetScene.lighting) }
        var durationStr by remember(targetScene) { mutableStateOf(targetScene.durationSec.toString()) }

        AlertDialog(
            onDismissRequest = { editingScene = null },
            containerColor = StudioSurfaceElevated,
            title = { Text("Edit SCENE 0${targetScene.sceneNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = visual, onValueChange = { visual = it }, label = { Text("Visual Description") })
                    OutlinedTextField(value = camera, onValueChange = { camera = it }, label = { Text("Camera Direction") })
                    OutlinedTextField(value = lighting, onValueChange = { lighting = it }, label = { Text("Lighting") })
                    OutlinedTextField(value = voice, onValueChange = { voice = it }, label = { Text("Voice-Over & Subtitle") })
                    OutlinedTextField(value = durationStr, onValueChange = { durationStr = it }, label = { Text("Duration (sec)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSceneDetails(
                            scene = targetScene,
                            newVisual = visual,
                            newVoice = voice,
                            newCamera = camera,
                            newLighting = lighting,
                            newDuration = durationStr.toIntOrNull() ?: targetScene.durationSec
                        )
                        editingScene = null
                    }
                ) {
                    Text(i18n.t("common.save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { editingScene = null }) {
                    Text(i18n.t("common.cancel"))
                }
            }
        )
    }
}

@Composable
private fun DirectorInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "$label:",
            style = MaterialTheme.typography.labelLarge,
            color = StudioTextSecondary,
            modifier = Modifier.width(128.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = StudioTextPrimary,
            modifier = Modifier.weight(1f)
        )
    }
}

# AI Creative Studio

Android (Jetpack Compose) uygulaması: görsel, video, müzik, ses ve zaman çizelgesi stüdyosu.

## Kullanıcı kendi API anahtarını girer
Ana sayfadaki "Gemini API anahtarını gir" kartından kullanıcı kendi anahtarını yazar
(https://aistudio.google.com/apikey). Anahtar yalnızca cihazda saklanır ve yedeklenmez.
Anahtar yoksa uygulama demo modunda çalışır. Geliştirici anahtarı gerekmez.

## Yeni özellikler
- Metinden Şarkı: Müzik ekranında metin yaz veya .txt yükle, tür seç; yapay zeka söz yazar ve şarkıyı üretir.
- Üretilen müzik ve görseller cihazda saklanır; ana sayfada "Son üretimlerin" bölümünden dinle, önizle, paylaş/indir.
- Telefon düzeni düzeltildi (başlık çubuğu, alt menü etiketleri), modern ana sayfa.

## APK derleme
- GitHub: depoya yükle, Actions > Build APK > Run workflow. Çıkan "ai-creative-studio-debug-apk" dosyasını indir.
- Android Studio: projeyi aç, Build > Build APK. `debug.keystore` yoksa
  `keytool -genkeypair -keystore debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"` ile oluştur.

## Notlar
- `google-services.json` yoksa Firebase bulut özellikleri kapalı kalır, uygulama yine çalışır.
- Video üretimi (Veo) uzun işlem döner; sonucun cihaza kaydı şimdilik yalnızca müzik ve görsel için var.

## 2026 modernizasyon notları
- Gemini API anahtarı artık Android Keystore + AES/GCM ile şifrelenir; SharedPreferences içinde düz metin tutulmaz.
- Veo 3.1 üretimi güncel `predictLongRunning` + operation polling + MP4 indirme akışına geçirildi.
- Gemini 3.8 Flash TTS gerçek AI ses üretimi olarak eklendi; ses çıktısı WAV olarak cihazda saklanır ve paylaşılabilir.
- Başarısız VIDEO/IMAGE/VOICE/MUSIC üretimlerinde kredi otomatik olarak iade edilir.
- Üretim başlamadan önce yetersiz kredi kontrolü yapılır.
- Son üretimler rafına VIDEO ve VOICE çıktıları eklendi.
- Video üretimi artık sahte "COMPLETED" sonucu yerine gerçek MP4 döndürmediğinde FAILED olur.

### Ürün kararları
Benzer AI video uygulamalarının 2026 kullanıcı yorumlarında en sık görülen sorunlar: üretim bitmeden ücret/credit tüketilmesi, başarısız üretimlerde kredi kaybı, yüksek abonelik baskısı, yavaşlık, promptun görsele doğru yansımaması ve uygulamanın üretim sırasında kilitlenmesi. Bu sürümde özellikle şeffaf durum mesajları, başarısız işte kredi iadesi, gerçek çıktı doğrulaması ve BYOK yaklaşımı güçlendirildi.


## ZIP INTEGRITY
This distribution contains the complete Android source tree. The archive was recreated and verified with `unzip -t`. Android Studio can import the project root.
